/**
 * 
 */
/**
 * 
 */
module tipoparcial1 {
}