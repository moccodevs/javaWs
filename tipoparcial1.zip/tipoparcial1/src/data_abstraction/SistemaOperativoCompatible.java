package data_abstraction;

import recursos.RecursoMultimedia;

public class SistemaOperativoCompatible extends RecursoMultimedia{
	private String nombre;
}
