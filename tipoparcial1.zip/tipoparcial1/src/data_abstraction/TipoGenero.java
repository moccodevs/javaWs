package data_abstraction;

public enum TipoGenero {
	drama,comedia,accion
}
