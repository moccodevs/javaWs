package dataType;

public enum TipoComercializacion {
	online,
	tiendas
}
