package dataType;

public enum TipoTransporte {
	avion,
	tren,
	camion
}
