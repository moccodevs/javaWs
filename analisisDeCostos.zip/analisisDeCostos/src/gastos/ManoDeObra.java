package gastos;

public class ManoDeObra {
	private int horasDuracion;
	private double costoHora;
	public int getHorasDuracion() {
		return horasDuracion;
	}
	public void setHorasDuracion(int horasDuracion) {
		this.horasDuracion = horasDuracion;
	}
	public double getCostoHora() {
		return costoHora;
	}
	public void setCostoHora(double costoHora) {
		this.costoHora = costoHora;
	}
}
